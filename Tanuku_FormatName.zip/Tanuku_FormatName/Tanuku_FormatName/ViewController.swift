//
//  ViewController.swift
//  Tanuku_FormatName
//
//  Created by Tanuku,Venkata N on 9/9/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBOutlet weak var firstNameTextField: UITextField!
    
    @IBOutlet weak var lastNameTextField: UITextField!


    @IBOutlet weak var displayLabel: UILabel!
    @IBAction func onClickOfSubmit(_ sender: UIButton) {
        let firstText = firstNameTextField.text!
        let lastText = lastNameTextField.text!
        displayLabel.text = "\(firstText), \(lastText)"
        displayLabel.textColor = UIColor.red
        displayLabel.font = UIFont.italicSystemFont(ofSize: 32)
    }
    
    @IBAction func onClickOfReset(_ sender: UIButton) {
        firstNameTextField.text = ""
        lastNameTextField.text = nil
        displayLabel.text = nil
        firstNameTextField.becomeFirstResponder()
        
    }
}
